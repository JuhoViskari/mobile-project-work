package com.example.weatherproject.combosables

import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue

import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.weatherproject.DataClasses.ApiResponse
import com.example.weatherproject.DataClasses.fetchWeatherData
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun ForecastScreen(navController: NavController, latitude: Double, longitude: Double, ForecastTime: (String) -> Unit) {
    val coroutineScope = rememberCoroutineScope()

    var weatherResponse by remember {
        mutableStateOf<ApiResponse?>(null)
    }

    LaunchedEffect(Unit) {
        coroutineScope.launch {
            val response = fetchWeatherData(latitude, longitude)
            weatherResponse = response
        }
    }

    // Show loading indicator when
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        if (weatherResponse == null) {
            CircularProgressIndicator()
        } else {
            val days = weatherResponse?.daily?.time
            //val currentTemperature = weatherResponse?.current?.temperature_2m ?: 0.0
            val dailyTemperaturemax = weatherResponse?.daily?.temperature_2m_max
            val dailyTemperaturemin = weatherResponse?.daily?.temperature_2m_min
            val dailyweathercode = weatherResponse?.daily?.weather_code

            if (days != null && dailyTemperaturemin != null && dailyTemperaturemax != null
                && dailyweathercode != null
            ) {
                LazyColumn {
                    items(days.size) { index ->
                        val time = days[index]
                        val date = LocalDate.parse(time)
                        val formattedtime = date.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"))
                        val weekDay = date.dayOfWeek
                        val mintemp = dailyTemperaturemin[index]
                        val roundedmintemp = mintemp.roundToInt()
                        val maxtemp = dailyTemperaturemax[index]
                        val roundedmaxtemp = maxtemp.roundToInt()
                        val wc = dailyweathercode[index]

                        val finnishWeekDay = when (weekDay.name) {
                            "MONDAY" -> "MAANANTAI"
                            "TUESDAY" -> "TIISTAI"
                            "WEDNESDAY" -> "KESKIVIIKKO"
                            "THURSDAY" -> "TORSTAI"
                            "FRIDAY" -> "PERJANTAI"
                            "SATURDAY" -> "LAUANTAI"
                            "SUNDAY" -> "SUNNUNTAI"
                            else -> "PROBLEMS WITH WEEKDAYS"

                        }


                        val weatherDescriptionEmoji = when (wc.toIntOrNull()) {
                            0 -> "☀️"
                            1 -> "\uD83C\uDF24"
                            2 -> "\uD83C\uDF25"
                            3 -> "\uD83C\uDF25"
                            in 45..48 -> "☁️"
                            in 51..57 -> "\uD83C\uDF26"
                            in 61..67 -> "\uD83C\uDF27"
                            in 71..77 -> "\uD83C\uDF28"
                            80, 81, 82 -> "\uD83C\uDF27"
                            85, 86 -> "\uD83C\uDF28"
                            95 -> "\uD83C\uDF29"
                            96, 99 -> "\uD83C\uDF29"
                            else -> "\uD83D\uDC80"
                        }
                        val weatherDescription = when (wc.toIntOrNull()) {
                            0 -> "clear sky"
                            1 -> "Mainly clear"
                            2 -> "Partly cloudy"
                            3 -> "Overcast"
                            in 45..48 -> "Fog or depositing rime fog"
                            in 51..57 -> "Drizzle or freezing drizzle"
                            in 61..67 -> "Rain or freezing rain"
                            in 71..77 -> "Snow fall or snow grains"
                            80, 81, 82 -> "Rain showers"
                            85, 86 -> "Snow showers"
                            95 -> "Thunderstorm: light or moderate"
                            96, 99 -> "Thunderstorm with slight or heavy hail"
                            else -> "Unknown weather code"
                        }
                        Box {
                            Column(modifier = Modifier.padding(16.dp)) {

                                Button(
                                    onClick = {
                                        ForecastTime(time)
                                        navController.navigate("HourlyScreen/$time")
                                    },

                                    modifier = Modifier.padding(top = 16.dp),
                                    shape = RectangleShape
                                ) {
                                    Column {
                                        Text(
                                            text = "$weatherDescriptionEmoji",
                                            fontSize = 50.sp,
                                            modifier = Modifier.padding(bottom = 16.dp)
                                        )
                                        Text(
                                            text = "$finnishWeekDay",
                                            modifier = Modifier.padding(bottom = 8.dp)
                                        )
                                        Text(
                                            text = "$formattedtime",
                                            modifier = Modifier.padding(bottom = 8.dp)
                                        )
                                        Text(
                                            text = "$roundedmintemp / $roundedmaxtemp °C",
                                            modifier = Modifier.padding(bottom = 8.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}




