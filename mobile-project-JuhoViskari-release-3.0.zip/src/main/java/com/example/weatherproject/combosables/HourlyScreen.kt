package com.example.weatherproject.combosables

import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.weatherproject.DataClasses.ApiResponse
import com.example.weatherproject.DataClasses.fetchWeatherData
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun HourlyScreen(navController: NavController, latitude: Double, longitude: Double, selectedTime: String) {
    val coroutineScope = rememberCoroutineScope()

    var weatherResponse by remember {
        mutableStateOf<ApiResponse?>(null)
    }

    LaunchedEffect(Unit) {
        coroutineScope.launch {
            val response = fetchWeatherData(latitude, longitude)
            weatherResponse = response
        }
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        if (weatherResponse == null) {
            CircularProgressIndicator()
        } else {

            val hours = weatherResponse?.hourly?.time
            val hourlytemperature = weatherResponse?.hourly?.temperature_2m
            val hourlyweathercode = weatherResponse?.hourly?.weather_code
            val hourlywindspeed = weatherResponse?.hourly?.wind_speed_10m

            if (hours != null && hourlytemperature != null) {
                val filteredHours =
                    hours.withIndex().filter { it.value.startsWith(selectedTime) }.map { it.index }



                LazyColumn {
                    items(filteredHours.size) { index ->
                        val indexes = filteredHours[index]
                        val time = hours[indexes]
                        val formatTime =
                            LocalDateTime.parse(time, DateTimeFormatter.ISO_LOCAL_DATE_TIME)
                        val formattedtime = formatTime.format(DateTimeFormatter.ofPattern("HH:mm"))
                        val hourTemp = hourlytemperature[indexes]
                        val hourwc = hourlyweathercode?.get(index)
                        val hourws = hourlywindspeed?.get(indexes)
                        val hourwindspeedMS = String.format("%.1f", hourws?.div(3.6))

                        val weatherDescriptionEmoji = when (hourwc?.toIntOrNull()) {
                            0 -> "☀️"
                            1 -> "\uD83C\uDF24"
                            2 -> "\uD83C\uDF25"
                            3 -> "\uD83C\uDF25"
                            in 45..48 -> "☁️"
                            in 51..57 -> "\uD83C\uDF26"
                            in 61..67 -> "\uD83C\uDF27"
                            in 71..77 -> "\uD83C\uDF28"
                            80, 81, 82 -> "\uD83C\uDF27"
                            85, 86 -> "\uD83C\uDF28"
                            95 -> "\uD83C\uDF29"
                            96, 99 -> "\uD83C\uDF29"
                            else -> "\uD83D\uDC80"
                        }
                        Row(
                            modifier = Modifier
                                .padding(top = 50.dp)
                        ) {

                            Box(
                                modifier = Modifier
                                    .border(BorderStroke(2.dp, Color.Black))
                                    .padding(8.dp)
                            ) {
                                Text(
                                    text = formattedtime,
                                    modifier = Modifier.padding(4.dp),
                                    fontSize = 15.sp
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .border(BorderStroke(2.dp, Color.Black))
                                    .padding(8.dp)
                            ) {
                                Text(
                                    text = "$hourTemp °C",
                                    modifier = Modifier.padding(4.dp),
                                    fontSize = 15.sp
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .border(BorderStroke(2.dp, Color.Black))
                                    .padding(8.dp)
                            ) {
                                Text(
                                    text = weatherDescriptionEmoji,
                                    modifier = Modifier.padding(4.dp),
                                    fontSize = 15.sp
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .border(BorderStroke(2.dp, Color.Black))
                                    .padding(8.dp)
                            ) {
                                Text(
                                    text = "$hourwindspeedMS m/s \uD83D\uDCA8",
                                    modifier = Modifier.padding(4.dp),
                                    fontSize = 15.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}




