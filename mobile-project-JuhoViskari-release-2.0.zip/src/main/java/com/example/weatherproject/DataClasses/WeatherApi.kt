package com.example.weatherproject.DataClasses


import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

interface WeatherApi {
    @GET("forecast")
    suspend fun getWeather(
        @Query("latitude") latitude: Double,
        @Query("longitude") longitude: Double,
        @Query("current") current: String,
        @Query("hourly") hourly: String,
        @Query("daily") daily: String,
        @Query("timezone") timezone: String
    ): ApiResponse
}
// ApiResponse for current data
data class ApiResponse(
    val current: CurrentData,
    val hourly: HourlyData,
    val daily: DailyData
)
// Data class for Current Temperature and weather_code
data class CurrentData(
    val temperature_2m: Double,
    val weather_code: String
)

data class HourlyData(
    val temperature_2m: List<Double>
)

data class DailyData(
    val time: List<String>,
    val temperature_2m_max: List<Double>,
    val temperature_2m_min: List<Double>,
    val weather_code: List<String>
)

//  RetrofitInstance
object RetrofitInstance {
    private const val  BASE_URL = "https://api.open-meteo.com/v1/"

    private val getRetrofit: Retrofit by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }
    val weatherApi: WeatherApi by lazy {
        getRetrofit.create(WeatherApi::class.java)
    }

}
// fetch data from retrofit
suspend fun fetchWeatherData(latitude: Double, longitude: Double): ApiResponse {
    return withContext(Dispatchers.IO) {
        RetrofitInstance.weatherApi.getWeather(
            latitude,
            longitude,
            "temperature_2m,weather_code",
            "temperature_2m",
            "weather_code,temperature_2m_max,temperature_2m_min",
            "auto")
    }
}