package com.example.weatherproject.combosables

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.weatherproject.DataClasses.ApiResponse
import com.example.weatherproject.DataClasses.fetchWeatherData
import kotlinx.coroutines.launch

@Composable
fun TemperatureScreen(navController: NavController, latitude: Double, longitude: Double) {



        val coroutineScope = rememberCoroutineScope()

        var weatherResponse by remember {
            mutableStateOf<ApiResponse?>(null)
        }

        LaunchedEffect(Unit) {
            coroutineScope.launch {
                val response = fetchWeatherData(latitude, longitude)
                weatherResponse = response
            }
        }

        // Show loading indicator when
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            if (weatherResponse == null) {
                CircularProgressIndicator()
            }else{
                val currentTemperature = weatherResponse?.current?.temperature_2m ?: 0.0
                val weatherCode = weatherResponse?.current?.weather_code ?: ""

                val weatherDescriptionEmoji = when (weatherCode.toIntOrNull()) {
                    0 -> "☀️"
                    1 -> "\uD83C\uDF24"
                    2 -> "\uD83C\uDF25"
                    3 -> "\uD83C\uDF25"
                    in 45..48 -> "☁️"
                    in 51..57 -> "\uD83C\uDF26"
                    in 61..67 -> "\uD83C\uDF27"
                    in 71..77 -> "\uD83C\uDF28"
                    80, 81, 82 -> "\uD83C\uDF27"
                    85, 86 -> "\uD83C\uDF28"
                    95 -> "\uD83C\uDF29"
                    96, 99 -> "\uD83C\uDF29"
                    else -> "\uD83D\uDC80"
                }
                val weatherDescription = when (weatherCode.toIntOrNull()) {
                    0 -> "clear sky"
                    1 -> "Mainly clear"
                    2 -> "Partly cloudy"
                    3 -> "Overcast"
                    in 45..48 -> "Fog or depositing rime fog"
                    in 51..57 -> "Drizzle or freezing drizzle"
                    in 61..67 -> "Rain or freezing rain"
                    in 71..77 -> "Snow fall or snow grains"
                    80, 81, 82 -> "Rain showers"
                    85, 86 -> "Snow showers"
                    95 -> "Thunderstorm: light or moderate"
                    96, 99 -> "Thunderstorm with slight or heavy hail"
                    else -> "Unknown weather code"
                }


                Card(
                    modifier = Modifier.padding(16.dp),
                    border = BorderStroke(1.dp, Color.Black)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            modifier = Modifier.padding(start = 40.dp),
                            text = "Temperature: $currentTemperature °C",
                        )

                        Text(
                            modifier = Modifier.padding(start = 50.dp),
                            text = "$weatherDescriptionEmoji",
                            textAlign = TextAlign.Center,
                            fontSize = 100.sp
                        )
                        Text(
                            modifier = Modifier.padding(start = 80.dp),
                            text = "$weatherDescription",
                            textAlign = TextAlign.Center,
                        )
                        Button(
                            onClick = {
                                navController.navigate("forecastScreen")
                            },
                            modifier = Modifier.padding(top = 16.dp)
                        ) {
                            Text("Katso 7 päivän sääennuste")
                        }
                    }
                }
            }
        }
    }


