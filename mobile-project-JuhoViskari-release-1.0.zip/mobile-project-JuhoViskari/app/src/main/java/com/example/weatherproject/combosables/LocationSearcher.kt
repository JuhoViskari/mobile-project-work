package com.example.weatherproject.combosables

import android.Manifest
import android.location.Geocoder
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.weatherproject.Locationfiles.LocationViewModel
import java.util.Locale

@Composable
fun LocationSearcher() {
    val viewModel: LocationViewModel = viewModel()
    val location = viewModel.location

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions(),
        onResult = { permissions ->
            // Check if all requested permissions have been granted
            val allPermissionsGranted = permissions.entries.all { it.value }
            if (allPermissionsGranted) {
                viewModel.startLocationUpdates()
            }
        }
    )

    LaunchedEffect(Unit) {
        permissionLauncher.launch(
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
        )
    }

    // show location

    // Fetch human-readable address based on location
    location.value?.let { loc ->
        val geocoder = Geocoder(LocalContext.current, Locale.getDefault())
        var city: String? = null
        var country: String? = null
        try {
            val addresses = geocoder.getFromLocation(loc.latitude, loc.longitude, 1)
            if (addresses != null) {
                if (addresses.isNotEmpty()) {
                    val address = addresses[0]
                    city = address.locality
                    country = address.countryName
                }
            }
        } catch (e: Exception) {
            // Handle geocoding exceptions here
        }

        Text(text = location.value?.let { loc ->
            " $city, $country"
        } ?: "... waiting location")
    }
}