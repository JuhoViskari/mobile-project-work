package com.example.weatherproject
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.weatherproject.combosables.TemperatureScreen
import com.example.weatherproject.combosables.LocationSearcher
import com.example.weatherproject.Locationfiles.LocationViewModel
import com.example.weatherproject.ui.theme.WeatherprojectTheme


class MainActivity : ComponentActivity() {
    private lateinit var locationViewModel: LocationViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            WeatherprojectTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    TemperatureScreen()
                    LocationSearcher()

                }

            }
        }
    }
}

