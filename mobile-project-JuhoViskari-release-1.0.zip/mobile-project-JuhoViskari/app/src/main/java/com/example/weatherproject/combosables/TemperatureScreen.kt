package com.example.weatherproject.combosables

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.weatherproject.DataClasses.ApiResponse
import com.example.weatherproject.DataClasses.fetchWeatherData
import kotlinx.coroutines.launch

@Composable
fun TemperatureScreen() {
    val latitude = 61.50
    val longitude = 23.78

    val coroutineScope = rememberCoroutineScope()

    var weatherResponse by remember {
        mutableStateOf<ApiResponse?>(null)
    }

    LaunchedEffect(Unit) {
        coroutineScope.launch {
            val response = fetchWeatherData(latitude, longitude)
            weatherResponse = response
        }
    }

    // Show loading indicator when
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        if (weatherResponse != null) {
            val currentTemperature=(weatherResponse?.current?.temperature_2m ?: 0.0)
            Column(modifier = Modifier.padding(16.dp)) {
                Text(" Temperature: $currentTemperature °C")
            }
        } else {
            CircularProgressIndicator()
        }
    }
}
